Top-Down Racer (ماشین)
==========================
Kotlin بومی (بدون AndroidX) - minSdk 14 یعنی اندروید 4.0 تا آخرین نسخه

ساخت APK با GitHub Actions (بدون کامپیوتر):
1) در GitHub یک Repository جدید بساز.
2) تمام محتویات این زیپ را (بعد از Extract) در ریشه‌ی Repository آپلود کن.
   مهم: پوشه‌ی  .github/workflows/build.yml  هم باید آپلود شود.
   اگر آپلود پوشه‌ی نقطه‌دار نشد: Add file > Create new file بزن، اسم فایل را
   .github/workflows/build.yml بنویس و محتوای فایل build.yml را در آن Paste کن.
3) تب Actions > «Build APK» > Run workflow (یا خودکار بعد از commit اجرا می‌شود).
4) بعد از سبز شدن، پایین صفحه‌ی همان Run در بخش Artifacts فایل APK را دانلود کن
   (یک zip است؛ داخلش app-debug.apk).
5) APK را روی گوشی اندروید 4 نصب کن (Unknown sources / منابع ناشناس را روشن کن).
