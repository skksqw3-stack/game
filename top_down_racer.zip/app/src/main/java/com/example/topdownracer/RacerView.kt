package com.example.topdownracer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import java.util.Random

private fun col(r: Float, g: Float, b: Float, a: Float = 1f): Int =
    Color.argb((a * 255f + 0.5f).toInt(), (r * 255f + 0.5f).toInt(),
        (g * 255f + 0.5f).toInt(), (b * 255f + 0.5f).toInt())

private val BG_COLOR = col(0.08f, 0.10f, 0.12f)
private val ROAD_COLOR = col(0.15f, 0.15f, 0.18f)
private val LANE_COLOR = col(0.9f, 0.9f, 0.3f)
private val PLAYER_COLOR = col(0.2f, 0.9f, 1.0f)
private val ENEMY_COLOR = col(1.0f, 0.3f, 0.3f)
private val ENEMY_COLOR2 = col(1.0f, 0.6f, 0.2f)
private val POLICE_COLOR = col(0.3f, 0.4f, 1.0f)
private val COIN_COLOR = col(1.0f, 0.85f, 0.2f)
private val SHIELD_COLOR = col(0.3f, 1.0f, 0.6f)
private val GRASS_COLOR = col(0.10f, 0.25f, 0.15f)

/** ماشین دشمن / سکه / آیتم  (مختصات: y رو به بالا مثل Kivy) */
private class Obj(var x: Float, var y: Float, val color: Int = 0)

private class Explosion(val x: Float, val y: Float, var r: Float, var life: Float, val maxLife: Float)

class RacerView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val scaledDensity = resources.displayMetrics.scaledDensity
    private fun dp(v: Float): Float = v * density
    private fun sp(v: Float): Float = v * scaledDensity

    private val rnd = Random()
    private val handler = Handler(Looper.getMainLooper())
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tmp = RectF()

    // ---- ابعاد ----
    private var W = 0f
    private var H = 0f
    private var roadWidth = 0f
    private var roadLeft = 0f
    private var roadRight = 0f

    // ---- بازیکن ----
    private val carW = dp(45f)
    private val carH = dp(75f)
    private val carY = dp(160f)
    private var carX = 0f
    private val carFollowSpeed = dp(900f)

    // ---- اشیاء ----
    private val enemies = ArrayList<Obj>()
    private val coins = ArrayList<Obj>()
    private val powerups = ArrayList<Obj>()
    private var police: Obj? = null
    private val explosions = ArrayList<Explosion>()

    private var curveAmount = 0f
    private var lineOffset = 0f
    private var shieldActive = false

    // ---- وضعیت ----
    private var touching = false
    private var touchX = 0f
    private var enemySpeed = dp(350f)
    private var spawnTimer = 0f
    private var spawnInterval = 1.2f
    private var coinSpawnTimer = 0f
    private val coinSpawnInterval = 2.0f
    private var powerupSpawnTimer = 0f
    private val powerupSpawnInterval = 8.0f
    private var policeSpawnTimer = 0f
    private val policeSpawnInterval = 15.0f
    private var policeSpeed = dp(280f)

    private var curveTarget = 0f
    private var curveTimer = 0f
    private val curveChangeInterval = 4.0f
    private var shieldTimer = 0f

    private var score = 0
    private var scoreFrac = 0f
    private var coinCount = 0
    private var speedLevel = 1
    private var nextSpeedScore = 100
    private var running = false
    private var gameOver = false

    private var msg = "TOP-DOWN RACER\n\nDRAG TO MOVE"
    private var startText = "START"

    // ---- حلقه‌ی بازی ----
    private var lastNanos = 0L
    private var looping = false
    private val frame = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            var dt = (now - lastNanos) / 1_000_000_000f
            lastNanos = now
            if (dt > 0.05f) dt = 0.05f
            if (dt < 0f) dt = 0f
            update(dt)
            invalidate()
            if (looping) handler.postDelayed(this, 16L)
        }
    }

    fun startLoop() {
        if (looping) return
        looping = true
        lastNanos = System.nanoTime()
        handler.postDelayed(frame, 16L)
    }

    fun stopLoop() {
        looping = false
        handler.removeCallbacks(frame)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        W = w.toFloat()
        H = h.toFloat()
        roadWidth = minOf(W * 0.7f, dp(400f))
        roadLeft = (W - roadWidth) / 2f
        roadRight = roadLeft + roadWidth
        if (!running) carX = W / 2f - carW / 2f
    }

    // ---- ورودی لمسی ----
    private fun startBtnLeft() = W / 2f - dp(110f)
    private fun startBtnTop() = H * 0.85f - dp(80f)      // روی صفحه (y رو به پایین)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (running) {
                    touchX = e.x
                    touching = true
                } else {
                    val l = startBtnLeft()
                    val t = startBtnTop()
                    if (e.x >= l && e.x <= l + dp(220f) && e.y >= t && e.y <= t + dp(80f)) {
                        startGame()
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (touching && running) touchX = e.x
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching = false
            }
        }
        return true
    }

    // ---- شروع / پایان ----
    private fun startGame() {
        carX = W / 2f - carW / 2f
        enemies.clear(); coins.clear(); powerups.clear(); explosions.clear()
        police = null

        enemySpeed = dp(350f)
        spawnInterval = 1.2f
        spawnTimer = 0f
        coinSpawnTimer = 0f
        powerupSpawnTimer = 0f
        policeSpawnTimer = 0f
        policeSpeed = dp(280f)
        curveTarget = 0f
        curveAmount = 0f
        curveTimer = 0f
        shieldTimer = 0f
        shieldActive = false

        score = 0
        scoreFrac = 0f
        coinCount = 0
        speedLevel = 1
        nextSpeedScore = 100

        msg = ""
        running = true
        gameOver = false
    }

    private fun endGame() {
        running = false
        gameOver = true
        touching = false
        msg = "CRASH!\n\nSCORE: $score\nCOINS: $coinCount\nLEVEL: $speedLevel"
        startText = "RESTART"
    }

    // ---- تولید اشیاء ----
    private fun laneX(objW: Float): Float {
        val laneW = roadWidth / 4f
        val lane = rnd.nextInt(4)
        return roadLeft + lane * laneW + (laneW - objW) / 2f
    }

    private fun spawnEnemy() {
        enemies.add(Obj(laneX(carW), H + dp(10f), if (rnd.nextBoolean()) ENEMY_COLOR else ENEMY_COLOR2))
    }

    private fun spawnCoin() {
        coins.add(Obj(laneX(dp(22f)), H + dp(10f)))
    }

    private fun spawnPowerup() {
        powerups.add(Obj(laneX(dp(28f)), H + dp(10f)))
    }

    private fun spawnPolice() {
        if (police == null) police = Obj(W / 2f - carW / 2f, H + dp(20f))
    }

    private fun addExplosion(x: Float, y: Float) {
        explosions.add(Explosion(x, y, dp(10f), 0.5f, 0.5f))
    }

    private fun overlap(ax: Float, ay: Float, aw: Float, ah: Float,
                        bx: Float, by: Float, bw: Float, bh: Float): Boolean =
        ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by

    // ---- به‌روزرسانی ----
    private fun update(dt: Float) {
        if (!running || W <= 0f) return

        lineOffset += enemySpeed * dt

        // جاده‌ی خمیده
        curveTimer += dt
        if (curveTimer >= curveChangeInterval) {
            curveTimer = 0f
            curveTarget = (rnd.nextFloat() * 2f - 1f) * dp(60f)
        }
        curveAmount += (curveTarget - curveAmount) * dt * 2f

        // حرکت بازیکن
        if (touching) {
            val target = touchX - carW / 2f
            val diff = target - carX
            val step = carFollowSpeed * dt
            if (Math.abs(diff) <= step) carX = target
            else carX += if (diff > 0f) step else -step
        }

        // محدودیت جاده
        val tt = (carY / H).coerceIn(0f, 1f)
        val c = curveAmount * tt
        val leftLim = roadLeft + c
        val rightLim = roadRight + c - carW
        if (carX < leftLim) carX = leftLim
        if (carX > rightLim) carX = rightLim

        // جابجایی اشیاء
        for (e in enemies) e.y -= enemySpeed * dt
        enemies.removeAll { it.y + carH <= 0f }
        for (o in coins) o.y -= enemySpeed * dt
        coins.removeAll { it.y + dp(22f) <= 0f }
        for (o in powerups) o.y -= enemySpeed * dt
        powerups.removeAll { it.y + dp(28f) <= 0f }

        val pol = police
        if (pol != null) {
            pol.y -= policeSpeed * dt
            val dx = carX - pol.x
            if (Math.abs(dx) > dp(3f)) {
                val st = dp(60f) * dt
                pol.x += if (dx > 0f) st else -st
            }
            if (pol.y + carH < 0f) police = null
        }

        for (ex in explosions) {
            ex.life -= dt
            ex.r += dt * dp(80f)
        }
        explosions.removeAll { it.life <= 0f }

        // تولید
        spawnTimer += dt
        if (spawnTimer >= spawnInterval) { spawnTimer = 0f; spawnEnemy() }
        coinSpawnTimer += dt
        if (coinSpawnTimer >= coinSpawnInterval) { coinSpawnTimer = 0f; spawnCoin() }
        powerupSpawnTimer += dt
        if (powerupSpawnTimer >= powerupSpawnInterval) { powerupSpawnTimer = 0f; spawnPowerup() }
        policeSpawnTimer += dt
        if (policeSpawnTimer >= policeSpawnInterval) { policeSpawnTimer = 0f; spawnPolice() }

        if (shieldActive) {
            shieldTimer -= dt
            if (shieldTimer <= 0f) shieldActive = false
        }

        // برخوردها
        val px = carX + dp(6f)
        val py = carY + dp(6f)
        val pw = carW - dp(12f)
        val ph = carH - dp(12f)

        val coinIt = coins.iterator()
        while (coinIt.hasNext()) {
            val o = coinIt.next()
            if (overlap(px, py, pw, ph, o.x, o.y, dp(22f), dp(22f))) {
                coinIt.remove()
                coinCount += 1
                score += 5
            }
        }

        val puIt = powerups.iterator()
        while (puIt.hasNext()) {
            val o = puIt.next()
            if (overlap(px, py, pw, ph, o.x, o.y, dp(28f), dp(28f))) {
                puIt.remove()
                shieldActive = true
                shieldTimer = 6.0f
            }
        }

        val enIt = enemies.iterator()
        while (enIt.hasNext()) {
            val e = enIt.next()
            if (overlap(px, py, pw, ph, e.x + dp(6f), e.y + dp(6f), carW - dp(12f), carH - dp(12f))) {
                if (shieldActive) {
                    enIt.remove()
                    addExplosion(e.x + carW / 2f, e.y + carH / 2f)
                } else {
                    addExplosion(carX + carW / 2f, carY + carH / 2f)
                    endGame()
                    return
                }
            }
        }

        val pl = police
        if (pl != null) {
            if (overlap(px, py, pw, ph, pl.x + dp(6f), pl.y + dp(6f), carW - dp(12f), carH - dp(12f))) {
                if (shieldActive) {
                    addExplosion(pl.x + carW / 2f, pl.y + carH / 2f)
                    police = null
                } else {
                    addExplosion(carX + carW / 2f, carY + carH / 2f)
                    endGame()
                    return
                }
            }
        }

        // امتیاز (حدود ۶۰ امتیاز در ثانیه، مستقل از FPS)
        scoreFrac += dt * 60f
        val add = scoreFrac.toInt()
        if (add > 0) {
            score += add
            scoreFrac -= add
        }

        if (score >= nextSpeedScore) {
            speedLevel += 1
            enemySpeed += dp(60f)
            spawnInterval = maxOf(0.45f, spawnInterval - 0.12f)
            policeSpeed += dp(15f)
            nextSpeedScore += 100
            addExplosion(W / 2f, H * 0.85f)
        }
    }

    // ---- رسم (مختصات منطقی y رو به بالا → تبدیل به صفحه) ----
    private fun Canvas.box(x: Float, y: Float, w: Float, h: Float) {
        drawRect(x, H - y - h, x + w, H - y, paint)
    }

    private fun Canvas.oval(x: Float, y: Float, w: Float, h: Float) {
        tmp.set(x, H - y - h, x + w, H - y)
        drawOval(tmp, paint)
    }

    private fun Canvas.car(x: Float, y: Float, color: Int) {
        paint.color = color
        box(x, y, carW, carH)
        paint.color = col(0.1f, 0.1f, 0.1f, 0.8f)
        box(x + dp(6f), y + dp(10f), carW - dp(12f), dp(18f))
        paint.color = col(1f, 1f, 0.7f)
        box(x + dp(4f), y + carH - dp(4f), dp(8f), dp(4f))
        box(x + carW - dp(12f), y + carH - dp(4f), dp(8f), dp(4f))
    }

    override fun onDraw(canvas: Canvas) {
        if (W <= 0f) return
        paint.style = Paint.Style.FILL
        canvas.drawColor(GRASS_COLOR)

        val curve = curveAmount
        val steps = 20

        // جاده
        paint.color = ROAD_COLOR
        for (i in 0 until steps) {
            val y0 = H * i / steps
            val y1 = H * (i + 1) / steps
            val c0 = curve * (i.toFloat() / steps)
            val c1 = curve * ((i + 1).toFloat() / steps)
            canvas.box(roadLeft + (c0 + c1) / 2f, y0, roadWidth, y1 - y0)
        }

        // خطوط کناری سفید
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(3f)
        paint.color = Color.WHITE
        for (i in 0 until steps) {
            val y0 = H * i / steps
            val y1 = H * (i + 1) / steps
            val c0 = curve * (i.toFloat() / steps)
            val c1 = curve * ((i + 1).toFloat() / steps)
            canvas.drawLine(roadLeft + c0, H - y0, roadLeft + c1, H - y1, paint)
            canvas.drawLine(roadRight + c0, H - y0, roadRight + c1, H - y1, paint)
        }
        paint.style = Paint.Style.FILL

        // خط‌چین وسط
        paint.color = LANE_COLOR
        val lineH = dp(30f)
        val total = lineH + dp(40f)
        val offset = lineOffset % total
        var y = -total + offset
        while (y < H) {
            val t = (y / H).coerceIn(0f, 1f)
            val midX = W / 2f - dp(2f) + curve * t
            canvas.box(midX, y, dp(4f), lineH)
            y += total
        }

        // سکه‌ها
        for (c in coins) {
            paint.color = COIN_COLOR
            canvas.oval(c.x, c.y, dp(22f), dp(22f))
            paint.color = col(1f, 1f, 0.7f)
            canvas.oval(c.x + dp(7f), c.y + dp(7f), dp(8f), dp(8f))
        }

        // آیتم سپر
        for (p in powerups) {
            paint.color = SHIELD_COLOR
            canvas.oval(p.x, p.y, dp(28f), dp(28f))
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(2f)
            canvas.drawCircle(p.x + dp(14f), H - (p.y + dp(14f)), dp(9f), paint)
            paint.style = Paint.Style.FILL
        }

        // دشمن‌ها و پلیس
        for (e in enemies) canvas.car(e.x, e.y, e.color)

        val pol = police
        if (pol != null) {
            canvas.car(pol.x, pol.y, POLICE_COLOR)
            val flash = (System.nanoTime() / 250_000_000L) % 2L == 0L
            paint.color = if (flash) col(1f, 0f, 0f) else col(0.3f, 0.3f, 1f)
            canvas.box(pol.x + dp(8f), pol.y + carH - dp(10f), dp(10f), dp(6f))
        }

        // بازیکن
        canvas.car(carX, carY, PLAYER_COLOR)

        // سپر
        if (shieldActive) {
            paint.color = col(0.3f, 1f, 0.6f, 0.35f)
            canvas.oval(carX - dp(8f), carY - dp(8f), carW + dp(16f), carH + dp(16f))
            paint.color = col(0.3f, 1f, 0.6f, 0.9f)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(3f)
            canvas.drawCircle(carX + carW / 2f, H - (carY + carH / 2f), carW / 2f + dp(10f), paint)
            paint.style = Paint.Style.FILL
        }

        // انفجارها
        for (ex in explosions) {
            val a = (ex.life / ex.maxLife).coerceIn(0f, 1f)
            paint.color = col(1f, 0.6f, 0.1f, a)
            canvas.oval(ex.x - ex.r, ex.y - ex.r, ex.r * 2f, ex.r * 2f)
            paint.color = col(1f, 1f, 0.3f, a * 0.7f)
            canvas.oval(ex.x - ex.r * 0.5f, ex.y - ex.r * 0.5f, ex.r, ex.r)
        }

        drawHud(canvas)

        if (!running) {
            drawMessage(canvas)
            drawStartButton(canvas)
        }
    }

    /** متن وسط‌چین عمودی در یک جعبه به ارتفاع boxH که بالایش topY است */
    private fun drawTextIn(canvas: Canvas, text: String, x: Float, topY: Float, boxH: Float) {
        val cy = topY + boxH / 2f
        canvas.drawText(text, x, cy - (paint.ascent() + paint.descent()) / 2f, paint)
    }

    private fun drawHud(canvas: Canvas) {
        paint.style = Paint.Style.FILL
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.LEFT
        val x = W * 0.03f
        val boxH = dp(40f)

        paint.textSize = sp(22f)
        paint.color = Color.WHITE
        drawTextIn(canvas, "Score: $score  |  Lv.$speedLevel", x, H * 0.05f, boxH)

        paint.textSize = sp(20f)
        paint.color = COIN_COLOR
        drawTextIn(canvas, "Coins: $coinCount", x, H * 0.12f, boxH)

        if (shieldActive) {
            paint.textSize = sp(18f)
            paint.color = SHIELD_COLOR
            val secs = Math.ceil(shieldTimer.toDouble()).toInt()
            drawTextIn(canvas, "SHIELD: ${secs}s", x, H * 0.19f, boxH)
        }
        paint.isFakeBoldText = false
    }

    private fun drawMessage(canvas: Canvas) {
        if (msg.isEmpty()) return
        paint.style = Paint.Style.FILL
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = sp(20f)
        paint.color = Color.WHITE
        val lines = msg.split("\n")
        val lh = paint.textSize * 1.3f
        val startTop = H * 0.4f - lh * lines.size / 2f
        for (i in lines.indices) {
            drawTextIn(canvas, lines[i], W / 2f, startTop + i * lh, lh)
        }
        paint.isFakeBoldText = false
    }

    private fun drawStartButton(canvas: Canvas) {
        val l = startBtnLeft()
        val t = startBtnTop()
        paint.style = Paint.Style.FILL
        paint.color = col(0.2f, 0.8f, 0.4f, 0.95f)
        canvas.drawRect(l, t, l + dp(220f), t + dp(80f), paint)

        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = sp(28f)
        paint.color = Color.WHITE
        drawTextIn(canvas, startText, W / 2f, t, dp(80f))
        paint.isFakeBoldText = false
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopLoop()
    }
}
