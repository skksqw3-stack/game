package com.example.snakegame

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity(), SnakeView.Listener {

    private lateinit var game: SnakeView
    private lateinit var menu: LinearLayout
    private lateinit var title: TextView
    private val diffButtons = LinkedHashMap<String, Button>()
    private val themeButtons = LinkedHashMap<String, Button>()

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        game = SnakeView(this)
        game.listener = this

        val activity = this
        val root = object : FrameLayout(activity) {
            override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                super.onSizeChanged(w, h, oldw, oldh)
                relayout(w, h)
            }
        }
        root.setBackgroundColor(rgbf(0.05f, 0.05f, 0.08f))
        root.addView(game, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        buildMenu()
        val menuLp = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        menuLp.gravity = Gravity.CENTER
        root.addView(menu, menuLp)

        setContentView(root)
    }

    private fun relayout(w: Int, h: Int) {
        val lp = menu.layoutParams as FrameLayout.LayoutParams
        lp.width = (w * (if (w < h) 0.9f else 0.6f)).toInt()
        lp.height = (h * 0.88f).toInt()
        lp.gravity = Gravity.CENTER
        menu.layoutParams = lp
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, minOf(w, h) * 0.085f)
    }

    private fun label(text: String, sp: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        t.gravity = Gravity.CENTER
        return t
    }

    private fun menuButton(text: String, sp: Float): Button {
        val b = Button(this)
        b.text = text
        b.textSize = sp
        b.setTypeface(Typeface.DEFAULT_BOLD)
        b.setTextColor(Color.WHITE)
        b.minimumHeight = 0
        b.minimumWidth = 0
        b.setPadding(0, 0, 0, 0)
        return b
    }

    private fun weighted(weight: Float): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, 0, weight)
        val m = dp(5f).toInt()
        lp.setMargins(0, m, 0, m)
        return lp
    }

    private fun buildMenu() {
        val pad = dp(15f).toInt()
        menu = LinearLayout(this)
        menu.orientation = LinearLayout.VERTICAL
        menu.setPadding(pad, pad, pad, pad)

        title = label("SNAKE GAME", 30f, rgbf(0.3f, 1f, 0.5f))
        title.setTypeface(Typeface.DEFAULT_BOLD)
        menu.addView(title, weighted(0.15f))

        // ---- سختی ----
        menu.addView(label("Difficulty:", 20f, Color.WHITE), weighted(0.07f))
        val diffRow = LinearLayout(this)
        diffRow.orientation = LinearLayout.HORIZONTAL
        val m3 = dp(3f).toInt()
        for (name in DIFFICULTIES.keys) {
            val b = menuButton(name, 15f)
            b.setOnClickListener { setDifficulty(name) }
            val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            lp.setMargins(m3, 0, m3, 0)
            diffRow.addView(b, lp)
            diffButtons[name] = b
        }
        menu.addView(diffRow, weighted(0.13f))

        val info = label(
            "Free mode: walls do nothing, snake wraps around.\n" +
                "Only head-to-tail collision ends the game.",
            13f, rgbf(0.7f, 0.9f, 1f)
        )
        menu.addView(info, weighted(0.09f))

        // ---- تم ----
        menu.addView(label("Theme:", 20f, Color.WHITE), weighted(0.07f))
        val themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        for (name in THEMES.keys) {
            val b = menuButton(name, 15f)
            b.setOnClickListener { setTheme(name) }
            val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            lp.setMargins(m3, 0, m3, 0)
            themeRow.addView(b, lp)
            themeButtons[name] = b
        }
        menu.addView(themeRow, weighted(0.13f))

        // ---- شروع ----
        val start = menuButton("START", 26f)
        start.setBg(buttonBg(rgbf(0.2f, 0.8f, 0.4f), dp(8f)))
        start.setOnClickListener { startFromMenu() }
        menu.addView(start, weighted(0.15f))

        refreshStyles()
    }

    private fun refreshStyles() {
        val r = dp(8f)
        for ((n, b) in diffButtons) {
            b.setBg(buttonBg(
                if (n == game.difficulty) rgbf(0.2f, 0.7f, 0.4f) else rgbf(0.3f, 0.3f, 0.35f), r))
        }
        for ((n, b) in themeButtons) {
            b.setBg(buttonBg(
                if (n == game.themeName) rgbf(0.3f, 0.55f, 0.9f) else rgbf(0.3f, 0.3f, 0.35f), r))
        }
    }

    private fun setDifficulty(name: String) {
        game.difficulty = name
        refreshStyles()
    }

    private fun setTheme(name: String) {
        game.themeName = name
        refreshStyles()
    }

    private fun startFromMenu() {
        menu.visibility = View.GONE
        game.startGame()
    }

    private fun backToMenu() {
        menu.visibility = View.VISIBLE
        game.toMenu()
    }

    // ---- رویدادهای SnakeView ----
    override fun onPlayAgain() {
        startFromMenu()
    }

    override fun onBackToMenu() {
        backToMenu()
    }

    // ---- چرخه‌ی حیات ----
    override fun onPause() {
        super.onPause()
        game.pauseGame()
    }

    override fun onBackPressed() {
        if (menu.visibility != View.VISIBLE) backToMenu() else super.onBackPressed()
    }
}
