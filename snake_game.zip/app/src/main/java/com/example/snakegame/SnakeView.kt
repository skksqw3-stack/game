package com.example.snakegame

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import java.util.Random

class SnakeView(context: Context) : View(context) {

    enum class State { MENU, PLAYING, PAUSED, GAMEOVER }

    interface Listener {
        fun onPlayAgain()
        fun onBackToMenu()
    }

    var listener: Listener? = null
    var difficulty = "Free"
    var themeName = "Night"
        set(value) {
            field = value
            invalidate()
        }
    var state = State.MENU
        private set

    private val rnd = Random()
    private val handler = Handler(Looper.getMainLooper())
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    private var cols = 18
    private var rows = 24
    private var wallsActive = false
    private var baseSpeed = 0.14f
    private var speed = 0.14f

    private val snake = ArrayList<Cell>()
    private var dirX = 0
    private var dirY = -1
    private var nextX = 0
    private var nextY = -1
    private var food: Cell? = null
    private var score = 0
    private var best = 0

    // سوایپ
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var touchId = -1

    private val tickRunnable = object : Runnable {
        override fun run() {
            tick()
            if (state == State.PLAYING) handler.postDelayed(this, (speed * 1000f).toLong())
        }
    }

    init {
        resetData()
    }

    // ---------- داده ----------
    private fun resetData() {
        val t = DIFFICULTIES[difficulty] ?: DIFFICULTIES["Free"]!!
        cols = t.cols
        rows = t.rows
        wallsActive = t.walls
        baseSpeed = t.speed

        val cx = cols / 2
        val cy = rows / 2
        snake.clear()
        snake.add(Cell(cx, cy))
        snake.add(Cell(cx, cy + 1))
        snake.add(Cell(cx, cy + 2))
        dirX = 0; dirY = -1
        nextX = 0; nextY = -1
        food = spawnFood()
        score = 0
        speed = baseSpeed
    }

    private fun spawnFood(): Cell? {
        val free = ArrayList<Cell>()
        for (x in 0 until cols) {
            for (y in 0 until rows) {
                val c = Cell(x, y)
                if (!snake.contains(c)) free.add(c)
            }
        }
        return if (free.isEmpty()) null else free[rnd.nextInt(free.size)]
    }

    // ---------- کنترل بازی ----------
    fun startGame() {
        resetData()
        state = State.PLAYING
        handler.removeCallbacks(tickRunnable)
        handler.postDelayed(tickRunnable, (speed * 1000f).toLong())
        invalidate()
    }

    fun toMenu() {
        handler.removeCallbacks(tickRunnable)
        state = State.MENU
        invalidate()
    }

    fun pauseGame() {
        if (state != State.PLAYING) return
        state = State.PAUSED
        handler.removeCallbacks(tickRunnable)
        invalidate()
    }

    fun resumeGame() {
        if (state != State.PAUSED) return
        state = State.PLAYING
        handler.removeCallbacks(tickRunnable)
        handler.postDelayed(tickRunnable, (speed * 1000f).toLong())
        invalidate()
    }

    private fun tick() {
        if (state != State.PLAYING) return

        dirX = nextX
        dirY = nextY
        val head = snake[0]
        var nx = head.x + dirX
        var ny = head.y + dirY

        if (wallsActive) {
            if (nx < 0 || nx >= cols || ny < 0 || ny >= rows) {
                gameOver()
                return
            }
        } else {
            // حالت Free: از لبه‌ها رد می‌شود
            nx = ((nx % cols) + cols) % cols
            ny = ((ny % rows) + rows) % rows
        }

        // برخورد سر با بدن (بدون دم)
        for (i in 0 until snake.size - 1) {
            val c = snake[i]
            if (c.x == nx && c.y == ny) {
                gameOver()
                return
            }
        }

        val newHead = Cell(nx, ny)
        snake.add(0, newHead)

        if (newHead == food) {
            score += 1
            food = spawnFood()
            speed = maxOf(0.06f, baseSpeed - score * 0.003f)
        } else {
            snake.removeAt(snake.size - 1)
        }
        invalidate()
    }

    private fun gameOver() {
        state = State.GAMEOVER
        if (score > best) best = score
        handler.removeCallbacks(tickRunnable)
        invalidate()
    }

    // ---------- ورودی لمسی ----------
    private fun metricsCell(): Float {
        val w = width.toFloat()
        val h = height.toFloat()
        val margin = 0.08f * h
        return minOf(w / cols, (h - 2 * margin) / rows)
    }

    private fun insidePlayfield(x: Float, y: Float): Boolean {
        val cell = metricsCell()
        val gw = cell * cols
        val gh = cell * rows
        val ox = (width - gw) / 2f
        val oy = (height - gh) / 2f
        return x >= ox && x <= ox + gw && y >= oy && y <= oy + gh
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (state) {
            State.GAMEOVER -> {
                if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                    // پایین صفحه (۲۵٪) = منو ، بقیه = بازی دوباره
                    if (e.y > height * 0.75f) listener?.onBackToMenu() else listener?.onPlayAgain()
                }
                return true
            }
            State.PAUSED -> {
                if (e.actionMasked == MotionEvent.ACTION_DOWN) resumeGame()
                return true
            }
            State.PLAYING -> {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        if (insidePlayfield(e.x, e.y)) {
                            touchStartX = e.x
                            touchStartY = e.y
                            touchId = e.getPointerId(0)
                        } else {
                            touchId = -1
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (touchId != -1) {
                            val dx = e.x - touchStartX
                            val dy = -(e.y - touchStartY)   // محور y بازی رو به بالاست
                            touchId = -1
                            val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                            if (dist >= SWIPE_MIN_DISTANCE) {
                                if (Math.abs(dx) > Math.abs(dy)) {
                                    setDirection(if (dx > 0) 1 else -1, 0)
                                } else {
                                    setDirection(0, if (dy > 0) 1 else -1)
                                }
                            }
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> touchId = -1
                }
                return true
            }
            else -> return false
        }
    }

    private fun setDirection(nx: Int, ny: Int) {
        if (nx == -dirX && ny == -dirY) return
        nextX = nx
        nextY = ny
    }

    // ---------- رسم ----------
    override fun onDraw(canvas: Canvas) {
        val t = THEMES[themeName] ?: THEMES["Night"]!!
        val w = width.toFloat()
        val h = height.toFloat()

        val cell = metricsCell()
        val gw = cell * cols
        val gh = cell * rows
        val ox = (w - gw) / 2f
        val oyTop = (h - gh) / 2f       // لبه‌ی بالای گرید روی صفحه
        val gridBottom = oyTop + gh

        paint.style = Paint.Style.FILL
        canvas.drawColor(t.bg)

        // گرید شطرنجی
        paint.color = t.grid
        for (x in 0 until cols) {
            for (y in 0 until rows) {
                if ((x + y) % 2 == 0) {
                    val l = ox + x * cell
                    val tp = oyTop + (rows - 1 - y) * cell
                    canvas.drawRect(l, tp, l + cell, tp + cell, paint)
                }
            }
        }

        // قاب
        paint.color = if (wallsActive) t.head else Color.argb(153, 102, 102, 102)
        canvas.drawRect(ox - 2, oyTop - 2, ox + gw + 2, oyTop, paint)             // بالا
        canvas.drawRect(ox - 2, gridBottom, ox + gw + 2, gridBottom + 2, paint)    // پایین
        canvas.drawRect(ox - 2, oyTop - 2, ox, gridBottom + 2, paint)              // چپ
        canvas.drawRect(ox + gw, oyTop - 2, ox + gw + 2, gridBottom + 2, paint)    // راست

        // غذا
        val f = food
        if (f != null) {
            paint.color = t.food
            val fl = ox + f.x * cell
            val ft = oyTop + (rows - 1 - f.y) * cell
            rect.set(fl + cell * 0.15f, ft + cell * 0.15f, fl + cell * 0.85f, ft + cell * 0.85f)
            canvas.drawRoundRect(rect, cell * 0.35f, cell * 0.35f, paint)
        }

        // مار
        val n = snake.size
        val pad = cell * 0.06f
        for (i in 0 until n) {
            val c = snake[i]
            if (i == 0) {
                paint.color = t.head
            } else {
                val k = 1f - (i.toFloat() / maxOf(1, n)) * 0.4f
                paint.color = Color.rgb(
                    (Color.red(t.body) * k).toInt(),
                    (Color.green(t.body) * k).toInt(),
                    (Color.blue(t.body) * k).toInt()
                )
            }
            val l = ox + c.x * cell + pad
            val tp = oyTop + (rows - 1 - c.y) * cell + pad
            rect.set(l, tp, l + cell - 2 * pad, tp + cell - 2 * pad)
            canvas.drawRoundRect(rect, cell * 0.25f, cell * 0.25f, paint)
        }

        // HUD
        paint.color = t.text
        paint.textAlign = Paint.Align.LEFT
        paint.textSize = h * 0.03f
        canvas.drawText("Score: $score     Best: $best", ox, oyTop - 8f - paint.descent(), paint)

        // راهنمای سوایپ
        if (state == State.PLAYING && score == 0 && snake.size == 3) {
            paint.color = Color.argb(204, 179, 179, 179)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = h * 0.025f
            canvas.drawText("Swipe to move", w / 2f, gridBottom + h * 0.045f, paint)
        }

        if (state == State.GAMEOVER) drawGameOver(canvas, t, w, h)
        else if (state == State.PAUSED) drawPaused(canvas, t, w, h)
    }

    private fun drawGameOver(canvas: Canvas, t: Theme, w: Float, h: Float) {
        paint.color = Color.argb(166, 0, 0, 0)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.textAlign = Paint.Align.CENTER

        paint.color = rgbf(1f, 0.4f, 0.4f)
        paint.textSize = h * 0.07f
        canvas.drawText("GAME OVER", w / 2f, h * 0.35f, paint)

        paint.color = t.text
        paint.textSize = h * 0.035f
        canvas.drawText("Final Score: $score     Best: $best", w / 2f, h * 0.45f, paint)

        paint.color = rgbf(0.8f, 0.8f, 0.8f)
        paint.textSize = h * 0.025f
        canvas.drawText("Tap TOP to play again    Tap BOTTOM for menu", w / 2f, h * 0.70f, paint)
    }

    private fun drawPaused(canvas: Canvas, t: Theme, w: Float, h: Float) {
        paint.color = Color.argb(128, 0, 0, 0)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.textAlign = Paint.Align.CENTER

        paint.color = t.text
        paint.textSize = h * 0.08f
        canvas.drawText("PAUSED", w / 2f, h * 0.45f, paint)

        paint.color = rgbf(0.8f, 0.8f, 0.8f)
        paint.textSize = h * 0.03f
        canvas.drawText("Tap to resume", w / 2f, h * 0.55f, paint)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacks(tickRunnable)
    }
}
